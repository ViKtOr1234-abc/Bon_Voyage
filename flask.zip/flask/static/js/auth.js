// static/js/auth.js
document.addEventListener('DOMContentLoaded', () => {
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const errorEl = document.getElementById('error');
    const successEl = document.getElementById('success');

    // === ВХІД ===
    loginBtn?.addEventListener('click', async () => {
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;

        if (!username || !password) return showError('Заповніть усі поля');

        const res = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();

        if (data.success) {
            window.location.href = data.is_admin ? 'admin/dashboard.html' : 'index.html';
        } else {
            showError(data.error || 'Помилка входу');
        }
    });

    // === РЕЄСТРАЦІЯ ===
    registerBtn?.addEventListener('click', async () => {
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const confirm = document.getElementById('confirm')?.value;
        const name = document.getElementById('name')?.value.trim() || '';
        const phone = document.getElementById('phone')?.value.trim() || '';
        const email = document.getElementById('email')?.value.trim() || '';

        if (!username || !password) return showError('Заповніть логін і пароль');
        if (password !== confirm) return showError('Паролі не збігаються');
        if (password.length < 6) return showError('Пароль має бути ≥ 6 символів');

        const payload = { username, password, name, phone, email };

        const res = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();

        if (data.success) {
            showSuccess('Реєстрація успішна! Вхід...');
            setTimeout(() => window.location.href = 'login.html', 1500);
        } else {
            showError(data.error || 'Помилка');
        }
    });

    function showError(msg) {
        if (errorEl) errorEl.textContent = msg;
        if (successEl) successEl.textContent = '';
    }

    function showSuccess(msg) {
        if (successEl) successEl.textContent = msg;
        if (errorEl) errorEl.textContent = '';
    }

    // === НАВІГАЦІЯ ===
    if (!['login.html', 'register.html'].includes(location.pathname.split('/').pop())) {
        checkAuthAndUpdateNav();
    }
});

// === НАВІГАЦІЯ ПІСЛЯ ЛОГІНА ===
async function checkAuthAndUpdateNav() {
    try {
        const res = await fetch('/api/check-auth');
        const data = await res.json();
        
        const nav = document.querySelector('nav');
        if (!nav) return;

        // Сховуємо/показуємо посилання на авторизацію
        const authLinks = nav.querySelectorAll('.auth-link-static');
        authLinks.forEach(link => {
            link.style.display = data.authenticated ? 'none' : 'block';
        });

        // Видаляємо старі динамічні посилання
        nav.querySelectorAll('.auth-link, .admin-panel-btn').forEach(el => el.remove());

        // Якщо користувач авторизований
        if (data.authenticated) {
            let links = '';

            // КНОПКА "ПАНЕЛЬ КЕРУВАННЯ" --- ТІЛЬКИ ДЛЯ АДМІНА
            if (data.is_admin) {
                links += `
                    <div class="admin-panel-btn">
                        <a href="../admin/dashboard.html">Панель керування</a>
                    </div>
                `;
            } else {
                // "МІЙ КАБІНЕТ" --- ТІЛЬКИ ДЛЯ ЗВИЧАЙНИХ КОРИСТУВАЧІВ
                links += `
                <div class="auth-link">
                    <a class="page-link" href="profile.html">Мій кабінет</a>
                </div>
                `;
            }

            // ВИХІД --- ДЛЯ ВСІХ АВТОРИЗОВАНИХ
            links += `
                <div class="auth-link">
                    <a href="#" id="logoutBtn">Вихід</a>
                </div>
            `;

            nav.insertAdjacentHTML('beforeend', links);

            // Обробник виходу
            document.getElementById('logoutBtn')?.addEventListener('click', async (e) => {
                e.preventDefault();
                
                try {
                    await fetch('/api/logout', { method: 'POST' });
                } catch (error) {
                    console.error('Logout API error:', error);
                } finally {
                    const currentPath = window.location.pathname;
                    let redirectPath = '/index.html';
                    
                    if (currentPath.includes('/admin/')) {
                        redirectPath = '/index.html';
                    }
                    
                    window.location.href = redirectPath;
                }
            });
        }

    } catch (err) {
        console.error('Auth check error:', err);
    }
}

