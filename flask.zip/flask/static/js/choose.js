// static/js/choose.js

document.addEventListener('DOMContentLoaded', function() {
    loadTours();
});

function loadTours() {
    fetch('/api/tours')
        .then(response => response.json())
        .then(tours => {
            displayTours(tours);
        })
        .catch(error => {
            console.error('Error loading tours:', error);
            document.getElementById('toursContainer').innerHTML = 
                '<div class="error">Помилка завантаження турів. Спробуйте пізніше.</div>';
        });
}

function displayTours(tours) {
    const container = document.getElementById('toursContainer');
    
    if (tours.length === 0) {
        container.innerHTML = '<div class="no-data">Тури не знайдені</div>';
        return;
    }
    
    let html = '';
    tours.forEach(tour => {
        // Формуємо шлях до зображення
        const imagePath = tour.image_filename 
            ? `images/tours/${tour.image_filename}`
            : 'images/no-image.jpg';
        
        html += `
            <div class="tour-card">
                <img src="${imagePath}" alt="${tour.country}" 
                     onerror="this.src='images/no-image.jpg'">
                <div class="tour-info">
                    <h3>${tour.country} - ${tour.city}</h3>
                    <div class="tour-description">${tour.description || 'Чудова подорож для відпочинку'}</div>
                    <div class="tour-duration">Тривалість: ${tour.duration_days} днів</div>
                    <div class="tour-price"><strong>$${tour.new_price_usd} USD</strong></div>
                    <div class="tour-included">${tour.included || 'Проживання в готелі'}</div>
                </div>
                <div class="tour-actions">
                    <a href="javascript:void(0)" class="order-btn" data-id="${tour.id}" data-type="tour">Замовити</a>
                    <button class="favorite-btn" data-id="${tour.id}" data-type="tour">В обране</button>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;

    // Обробник кнопок "Замовити"
    document.querySelectorAll('.order-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            const type = btn.dataset.type;
            window.location.href = `order.html?${type}=${id}`;
        });
    });

    // Обробник кнопок "В обране"
    document.querySelectorAll('.favorite-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            const id = btn.dataset.id;
            const type = btn.dataset.type;
            
            try {
                const authCheck = await fetch('/api/check-auth');
                const authData = await authCheck.json();
                
                if (!authData.authenticated) {
                    alert('Будь ласка, увійдіть в систему щоб додавати в обране');
                    window.location.href = 'login.html';
                    return;
                }
                
                const res = await fetch(`/api/user/${authData.user_id}/favorites`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        item_type: type,
                        item_id: parseInt(id)
                    })
                });
                
                const result = await res.json();
                
                if (res.ok) {
                    // Успіх - змінюємо кнопку
                    btn.textContent = 'В обраному';
                    btn.disabled = true;
                    btn.style.background = '#27ae60';
                } else if (result.error === "Вже в обраному") {
                    // Вже в обраному
                    btn.textContent = 'В обраному';
                    btn.disabled = true;
                    btn.style.background = '#27ae60';
                }
                
            } catch (error) {
                console.error('Error adding to favorites:', error);
            }
        });
    });
}