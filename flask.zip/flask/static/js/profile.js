// profile.js
let currentUser = null;

document.addEventListener('DOMContentLoaded', async () => {
    try {
        const authCheck = await fetch('/api/check-auth');
        const authData = await authCheck.json();
        
        if (!authData.authenticated) {
            alert('Будь ласка, увійдіть в систему');
            window.location.href = 'login.html';
            return;
        }
        
        currentUser = authData;
        await loadUserProfile();
        await loadUserOrders();
        await loadUserFavorites();
    } catch (error) {
        window.location.href = 'login.html';
    }
});

async function loadUserProfile() {
    try {
        const res = await fetch(`/api/user/${currentUser.user_id}`);
        const userData = await res.json();
        
        document.getElementById('userName').textContent = userData.name || 'Не вказано';
        document.getElementById('userPhone').textContent = userData.phone || 'Не вказано';
        document.getElementById('userEmail').textContent = userData.email || 'Не вказано';
        
        document.getElementById('editName').value = userData.name || '';
        document.getElementById('editPhone').value = userData.phone || '';
        document.getElementById('editEmail').value = userData.email || '';
        
    } catch (error) {
        alert('Помилка завантаження даних профілю');
    }
}

async function loadUserOrders() {
    try {
        const res = await fetch(`/api/user/${currentUser.user_id}/orders`);
        const orders = await res.json();
        displayOrders(orders);
    } catch (error) {
        document.getElementById('ordersList').innerHTML = '<div class="error">Помилка завантаження замовлень</div>';
    }
}

async function loadUserFavorites() {
    try {
        const res = await fetch(`/api/user/${currentUser.user_id}/favorites`);
        const favorites = await res.json();
        displayFavorites(favorites);
    } catch (error) {
        document.getElementById('favoritesList').innerHTML = '<div class="error">Помилка завантаження обраного</div>';
    }
}

function displayOrders(orders) {
    const container = document.getElementById('ordersList');
    
    if (orders.length === 0) {
        container.innerHTML = '<div class="no-data">У вас ще немає замовлень</div>';
        return;
    }
    
    let html = '';
    orders.forEach(order => {
        const statusClass = `status-${order.status}`;
        html += `
            <div class="order-item">
                <div class="order-header">
                    <span class="order-tour">${order.country} - ${order.city}</span>
                    <span class="order-status ${statusClass}">${getStatusText(order.status)}</span>
                </div>
                <div class="order-details">
                    <div>Дата: ${new Date(order.order_date).toLocaleDateString('uk-UA')}</div>
                    <div>Тип: ${order.item_type === 'tour' ? 'Тур' : 'Акція'}</div>
                    ${order.notes ? `<div>Примітки: ${order.notes}</div>` : ''}
                </div>
                <div class="order-price">${order.price ? order.price + ' USD' : 'Ціна не вказана'}</div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

function displayFavorites(favorites) {
    const container = document.getElementById('favoritesList');
    
    if (favorites.length === 0) {
        container.innerHTML = '<div class="no-data">Поки що немає обраних турів</div>';
        return;
    }
    
    let html = '';
    favorites.forEach(fav => {
        html += `
            <div class="favorite-item">
                <div class="favorite-info">
                    <h4>${fav.country} - ${fav.city}</h4>
                    <div>${fav.duration_days} днів • ${fav.item_type === 'tour' ? 'Тур' : 'Акція'}</div>
                    <div class="favorite-price">${fav.price} USD</div>
                    ${fav.included ? `<div class="favorite-included">${fav.included}</div>` : ''}
                </div>
                <button class="btn-remove" onclick="removeFromFavorites(${fav.id})">Видалити</button>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

function getStatusText(status) {
    const statusMap = {
        'new': 'Очікує підтвердження',
        'confirmed': 'Підтверджено', 
        'cancelled': 'Скасовано',
        'paid': 'Оплачено',
        'processing': 'В обробці'
    };
    return statusMap[status] || status;
}

function openEditModal() {
    document.getElementById('editModal').style.display = 'flex';
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

document.getElementById('editForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const submitBtn = e.target.querySelector('button');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Збереження...';
    
    try {
        const formData = {
            name: document.getElementById('editName').value,
            phone: document.getElementById('editPhone').value,
            email: document.getElementById('editEmail').value
        };
        
        const res = await fetch(`/api/user/${currentUser.user_id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        
        const result = await res.json();
        
        if (!res.ok) throw new Error(result.error || 'Помилка оновлення даних');
        
        alert('Дані успішно оновлено!');
        closeEditModal();
        await loadUserProfile();
        
    } catch (error) {
        alert('Помилка оновлення даних: ' + error.message);
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Зберегти зміни';
    }
});

async function removeFromFavorites(favId) {
    if (!confirm('Видалити з обраного?')) return;
    
    try {
        await fetch(`/api/user/${currentUser.user_id}/favorites/${favId}`, { method: 'DELETE' });
        await loadUserFavorites();
    } catch (error) {
        alert('Помилка видалення');
    }
}

window.addEventListener('click', (e) => {
    const modal = document.getElementById('editModal');
    if (e.target === modal) closeEditModal();
});