// static/js/order.js
document.addEventListener('DOMContentLoaded', async () => {
    const params = new URLSearchParams(window.location.search);
    const tourId = params.get('tour');
    const promoId = params.get('promo');
    const promotionId = params.get('promotion'); // Добавляем поддержку promotion

    if (!tourId && !promoId && !promotionId) {
        document.getElementById('tourInfo').innerHTML = '<p class="error">Помилка: тур не знайдено</p>';
        return;
    }

    let item;
    if (tourId) {
        const res = await fetch('/api/tours');
        const tours = await res.json();
        item = tours.find(t => t.id == tourId);
        item.type = 'tour';
    } else {
        const res = await fetch('/api/promotions');
        const promos = await res.json();
        // Ищем по promoId ИЛИ promotionId
        const id = promoId || promotionId;
        item = promos.find(p => p.id == id);
        item.type = 'promotion';
    }

    if (!item) {
        document.getElementById('tourInfo').innerHTML = '<p class="error">Помилка: не знайдено</p>';
        return;
    }

    // Формуємо шлях до зображення
    const imagePath = item.image_filename 
        ? `images/${item.type === 'tour' ? 'tours' : 'promotions'}/${item.image_filename}`
        : 'images/no-image.jpg';

    document.getElementById('tourInfo').innerHTML = `
        <div class="tour-image">
            <img src="${imagePath}" alt="${item.country}" onerror="this.src='images/no-image.jpg'">
        </div>
        <h3>${item.country} - ${item.city}</h3>
        <p><strong>Тривалість:</strong> ${item.duration_days} днів</p>
        <p><strong>Ціна:</strong> <strong class="price">$${item.new_price_usd}</strong></p>
        ${item.discount_percent > 0 ? `
            <p><span class="discount-badge">-${item.discount_percent}%</span> <span class="old-price">$${item.old_price_usd}</span></p>
        ` : ''}
        <p><em>Включено: ${item.included || '—'}</em></p>
    `;

    // === АВТОЗАПОВНЕННЯ ===
    const fillUserData = async () => {
        try {
            const res = await fetch('/api/check-auth');
            const auth = await res.json();
            if (auth.authenticated) {
                const userRes = await fetch(`/api/user/${auth.user_id}`);
                const user = await userRes.json();
                document.querySelector('[name="name"]').value = user.name || '';
                document.querySelector('[name="phone"]').value = user.phone || '';
                document.querySelector('[name="email"]').value = user.email || '';
            }
        } catch (e) {
            console.log("Не авторизовано");
        }
    };
    await fillUserData();

    // === ВІДПРАВКА ФОРМИ ===
    document.getElementById('orderForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = {
            name: formData.get('name'),
            phone: formData.get('phone'),
            email: formData.get('email'),
            notes: formData.get('notes'),
            item_id: item.id,
            item_type: item.type
        };

        const submitBtn = e.target.querySelector('button');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Відправка...';

        try {
            const res = await fetch('/api/order', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await res.json();

            if (result.success) {
                document.getElementById('successMsg').textContent = result.message;
                document.getElementById('errorMsg').textContent = '';
                e.target.reset();
            } else {
                document.getElementById('errorMsg').textContent = result.error;
            }
        } catch (err) {
            document.getElementById('errorMsg').textContent = 'Помилка мережі';
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Надіслати замовлення';
        }
    });
});