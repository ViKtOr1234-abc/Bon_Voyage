const canvas = document.getElementById('logoCanvas');

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    ctx.beginPath();
    ctx.arc(20, height / 2, 10, 0, Math.PI * 2, true); 
    ctx.fillStyle = 'yellow'; 
    ctx.fill();

    ctx.font = 'bold 30px Lora, sans-serif'; 
    ctx.fillStyle = 'white'; 
    ctx.textAlign = 'left'; 
    ctx.textBaseline = 'middle'; 

    ctx.fillText('Bon Voyage', 35, height / 2); 
