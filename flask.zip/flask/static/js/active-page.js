// active-page.js - автоматичне виділення активної сторінки
function updateActivePage() {
    const pathParts = window.location.pathname.split('/');
    const currentPage = pathParts.pop(); // остання частина шляху
    const isAdmin = pathParts.includes('admin'); // чи це адмінка
    
    console.log('Пошук активної сторінки:', currentPage, 'Адмінка:', isAdmin);
    
    document.querySelectorAll('.page-link').forEach(link => {
        const linkHref = link.getAttribute('href');
        
        // Прибираємо active у всіх
        link.classList.remove('active');
        
        // Для звичайних сторінок
        if (linkHref === currentPage) {
            link.classList.add('active');
            console.log('Знайдено активне посилання:', linkHref);
        }
        
        // Для адмінки - спеціальна логіка
        if (isAdmin && linkHref === '../admin/dashboard.html' && currentPage === 'dashboard.html') {
            link.classList.add('active');
            console.log('Активна адмін-панель:', linkHref);
        }
    });
}

// Запускаємо при завантаженні
document.addEventListener('DOMContentLoaded', updateActivePage);

// Робимо функцію доступною глобально
window.updateActivePage = updateActivePage;

// Додатково: оновлюємо при зміні DOM
const observer = new MutationObserver(() => {
    updateActivePage();
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});