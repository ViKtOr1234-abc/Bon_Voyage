// static/js/admin.js
let currentType = ''; // 'tour' або 'promo'
let editId = null;

document.addEventListener('DOMContentLoaded', async () => {
    try {
        const authCheck = await fetch('/api/check-auth');
        const authData = await authCheck.json();
        
        if (!authData.authenticated || !authData.is_admin) {
            window.location.href = '../login.html';
            return;
        }
        
        await loadTours();
        await loadPromotions();
        
        // Оновлюємо навігацію в адмінці теж
        updateAdminNav(authData);
    } catch (error) {
        window.location.href = '../login.html';
    }
});

// Функція для оновлення навігації в адмінці
function updateAdminNav(authData) {
    const nav = document.querySelector('nav');
    if (!nav) return;

    // Сховуємо посилання на авторизацію
    const authLinks = nav.querySelectorAll('.auth-link-static');
    authLinks.forEach(link => {
        link.style.display = 'none';
    });

    // Видаляємо старі динамічні посилання
    nav.querySelectorAll('.auth-link, .admin-panel-btn').forEach(el => el.remove());

    // Додаємо посилання для адміна
    let links = `
        <div class="admin-panel-btn">
            <a class="page-link" href="../admin/dashboard.html">Панель керування</a>
        </div>
        <div class="auth-link">
            <a href="#" id="logoutBtn">Вихід</a>
        </div>
    `;

    nav.insertAdjacentHTML('beforeend', links);

    // Обробник виходу для адмінки
    document.getElementById('logoutBtn')?.addEventListener('click', async (e) => {
        e.preventDefault();
        
        try {
            await fetch('/api/logout', { method: 'POST' });
        } catch (error) {
            console.error('Logout API error:', error);
        } finally {
            window.location.href = '/index.html';
        }
    });
}

// Решта коду admin.js залишається без змін
async function loadTours() {
    try {
        const res = await fetch('/api/admin/tours');
        const tours = await res.json();
        displayItems(tours, 'toursList', 'tour');
    } catch (error) {
        document.getElementById('toursList').innerHTML = '<div class="error">Помилка завантаження турів</div>';
    }
}

async function loadPromotions() {
    try {
        const res = await fetch('/api/admin/promotions');
        const promos = await res.json();
        displayItems(promos, 'promosList', 'promo');
    } catch (error) {
        document.getElementById('promosList').innerHTML = '<div class="error">Помилка завантаження акцій</div>';
    }
}

function displayItems(items, containerId, type) {
    const container = document.getElementById(containerId);
    let html = '';
    
    items.forEach(item => {
        const price = type === 'tour' ? item.price_usd : item.new_price_usd;
        html += `
            <div class="item-card">
                <strong>${item.country} - ${item.city}</strong>
                <p>$${price} USD • ${item.duration_days} днів</p>
                ${item.image_filename ? `<div><small>Зображення: ${item.image_filename}</small></div>` : ''}
                <div class="item-actions">
                    <button onclick="editItem(${item.id}, '${type}')">Редагувати</button>
                    <button class="delete" onclick="deleteItem(${item.id}, '${type}')">Видалити</button>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html || '<p>Немає записів</p>';
}

function openModal(type, id = null) {
    currentType = type;
    editId = id;
    
    const modal = document.getElementById('modal');
    const title = document.getElementById('modalTitle');
    const form = document.getElementById('adminForm');

    title.textContent = id ? 'Редагувати запис' : 'Додати ' + (type === 'tour' ? 'тур' : 'акцію');
    modal.style.display = 'flex';

    form.innerHTML = `
        <input type="text" id="country" placeholder="Країна" required>
        <input type="text" id="city" placeholder="Місто" required>
        <textarea id="description" placeholder="Опис"></textarea>
        <input type="number" id="duration" placeholder="Днів" required min="1">
        ${type === 'promo' ? `
            <input type="number" id="discount" placeholder="Знижка %" min="0" max="100" required>
            <input type="number" id="oldPrice" placeholder="Стара ціна USD" min="0" required>
            <input type="number" id="newPrice" placeholder="Нова ціна USD" required min="0">
        ` : `
            <input type="number" id="price" placeholder="Ціна USD" required min="0">
        `}
        <textarea id="included" placeholder="Включено"></textarea>
        
        <div class="file-upload">
            <label>Зображення:</label>
            <input type="file" id="imageUpload" accept="image/*">
            <small>Дозволені формати: JPG, PNG, WebP. Макс. розмір: 5MB</small>
        </div>
        
        <button type="submit">${id ? 'Зберегти' : 'Додати'}</button>
    `;

    if (id) {
        const endpoint = type === 'promo' ? 'promotions' : 'tours';
        fetch(`/api/admin/${endpoint}/${id}`)
            .then(r => r.json())
            .then(data => {
                document.getElementById('country').value = data.country || '';
                document.getElementById('city').value = data.city || '';
                document.getElementById('description').value = data.description || '';
                document.getElementById('duration').value = data.duration_days || '';
                
                if (type === 'tour') {
                    document.getElementById('price').value = data.price_usd || '';
                } else {
                    document.getElementById('newPrice').value = data.new_price_usd || '';
                    document.getElementById('discount').value = data.discount_percent || 0;
                    document.getElementById('oldPrice').value = data.old_price_usd || '';
                }
                
                document.getElementById('included').value = data.included || '';
            });
    }

    form.onsubmit = async (e) => {
        e.preventDefault();
        
        const submitBtn = form.querySelector('button');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Збереження...';

        const formData = new FormData();
        formData.append('country', document.getElementById('country').value);
        formData.append('city', document.getElementById('city').value);
        formData.append('description', document.getElementById('description').value);
        formData.append('duration_days', document.getElementById('duration').value);
        formData.append('included', document.getElementById('included').value);

        if (type === 'tour') {
            formData.append('new_price_usd', document.getElementById('price').value);
        } else {
            formData.append('discount_percent', document.getElementById('discount').value);
            formData.append('old_price_usd', document.getElementById('oldPrice').value);
            formData.append('new_price_usd', document.getElementById('newPrice').value);
        }

        const fileInput = document.getElementById('imageUpload');
        if (fileInput.files[0]) {
            formData.append('image', fileInput.files[0]);
        }

        const endpoint = type === 'promo' ? 'promotions' : 'tours';
        const url = `/api/admin/${endpoint}${id ? '/' + id : ''}`;
        const method = id ? 'PUT' : 'POST';

        try {
            const response = await fetch(url, {
                method,
                body: formData
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText || 'Помилка сервера');
            }

            closeModal();
            if (type === 'tour') await loadTours();
            else await loadPromotions();
            
        } catch (error) {
            console.error('Error saving item:', error);
            alert('Помилка збереження: ' + error.message);
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = id ? 'Зберегти' : 'Додати';
        }
    };
}

function editItem(id, type) {
    openModal(type, id);
}

async function deleteItem(id, type) {
    if (!confirm('Видалити цей запис?')) return;
    
    try {
        const endpoint = type === 'promo' ? 'promotions' : 'tours';
        await fetch(`/api/admin/${endpoint}/${id}`, { method: 'DELETE' });
        
        if (type === 'tour') await loadTours();
        else await loadPromotions();
    } catch (error) {
        alert('Помилка видалення');
    }
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
    editId = null;
}

