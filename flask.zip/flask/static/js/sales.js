// static/js/sales.js
document.addEventListener('DOMContentLoaded', function() {
    loadPromotions();
});

function loadPromotions() {
    fetch('/api/promotions')
        .then(response => response.json())
        .then(promotions => {
            displayPromotions(promotions);
        })
        .catch(error => {
            console.error('Error loading promotions:', error);
            document.getElementById('promotionsContainer').innerHTML = 
                '<div class="error">Помилка завантаження акцій. Спробуйте пізніше.</div>';
        });
}

function displayPromotions(promotions) {
    const container = document.getElementById('promotionsContainer');
    
    if (promotions.length === 0) {
        container.innerHTML = '<div class="no-data">Акції не знайдені</div>';
        return;
    }
    
    let html = '';
    promotions.forEach(promo => {
        // Формуємо шлях до зображення
        const imagePath = promo.image_filename 
            ? `images/promotions/${promo.image_filename}`
            : 'images/no-image.jpg';
        
        html += `
            <div class="promotion-card">
                <img src="${imagePath}" alt="${promo.country}" 
                     onerror="this.src='images/no-image.jpg'">
                <div class="promo-header">
                    <h3>${promo.country} - ${promo.city}</h3>
                    <span class="discount-badge">-${promo.discount_percent}%</span>
                </div>
                <div class="promo-description">
                    ${promo.description || 'Спеціальна пропозиція!'}
                </div>
                <div class="promo-details">
                    <div class="duration">Тривалість: ${promo.duration_days} днів</div>
                    <div class="price-old">Стара ціна: $${promo.old_price_usd}</div>
                    <div class="price-new">Нова ціна: <strong>$${promo.new_price_usd}</strong></div>
                </div>
                <div class="included">
                    Включено: ${promo.included || 'Проживання та харчування'}
                </div>
                <div class="promo-actions">
                    <a href="javascript:void(0)" class="order-btn" data-id="${promo.id}" data-type="promo">Замовити</a>
                    <button class="favorite-btn" data-id="${promo.id}" data-type="promotion">В обране</button>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;

    // Обробник кнопок "Замовити"
    document.querySelectorAll('.order-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            const type = btn.dataset.type;
            window.location.href = `order.html?${type}=${id}`;
        });
    });

    // Обробник кнопок "В обране"
    document.querySelectorAll('.favorite-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            const id = btn.dataset.id;
            const type = btn.dataset.type;
            
            try {
                const authCheck = await fetch('/api/check-auth');
                const authData = await authCheck.json();
                
                if (!authData.authenticated) {
                    alert('Будь ласка, увійдіть в систему щоб додавати в обране');
                    window.location.href = 'login.html';
                    return;
                }
                
                const res = await fetch(`/api/user/${authData.user_id}/favorites`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        item_type: type,
                        item_id: parseInt(id)
                    })
                });
                
                const result = await res.json();
                
                if (res.ok) {
                    // Успіх - змінюємо кнопку
                    btn.textContent = 'В обраному';
                    btn.disabled = true;
                    btn.style.background = '#27ae60';
                } else if (result.error === "Вже в обраному") {
                    // Вже в обраному
                    btn.textContent = 'В обраному';
                    btn.disabled = true;
                    btn.style.background = '#27ae60';
                }
                
            } catch (error) {
                console.error('Error adding to favorites:', error);
            }
        });
    });
}