# app.py
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from flask import Flask
from config import Config
from database import init_app
from routes import init_routes

app = Flask(__name__, static_folder='static')
app.config.from_object(Config)

init_app(app)
init_routes(app)
if __name__ == '__main__':
    app.run(debug=app.config['DEBUG'])