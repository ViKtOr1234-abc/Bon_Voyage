# check_db.py
import sqlite3
from tabulate import tabulate

def check_database():
    try:
        conn = sqlite3.connect('data.db')
        cursor = conn.cursor()
        print("Підключення до бази даних успішне!\n")

        # === 1. Список таблиць ===
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = [row[0] for row in cursor.fetchall()]
        
        if not tables:
            print("У базі даних немає таблиць.")
            return
        
        print(f"Знайдено таблиць: {len(tables)} → {', '.join(tables)}\n")

        # === 2. Перевірка кожної таблиці ===
        # Оновлений список таблиць з reset_db.py
        expected_tables = ['promotions', 'tours', 'users', 'orders', 'favorites']
        
        for table_name in expected_tables:
            if table_name not in tables:
                print(f"ТАБЛИЦЯ `{table_name}` НЕ ІСНУЄ!\n")
                continue

            print(f"{'='*80}")
            print(f"ТАБЛИЦЯ: {table_name.upper()}")
            print(f"{'='*80}")
            
            try:
                # Кількість записів
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                count = cursor.fetchone()[0]
                print(f"Записів: {count}\n")
                
                if count == 0:
                    print("  → Таблиця порожня\n")
                    continue

                # Всі дані
                cursor.execute(f"SELECT * FROM {table_name}")
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]

                # Обрізаємо довгі рядки (наприклад, description)
                formatted_rows = []
                for row in rows:
                    formatted_row = []
                    for i, item in enumerate(row):
                        s = str(item) if item is not None else "NULL"
                        # Обрізаємо довгі поля
                        max_len = 50 if columns[i] == 'description' else 30
                        if len(s) > max_len:
                            s = s[:max_len-3] + "..."
                        formatted_row.append(s)
                    formatted_rows.append(formatted_row)

                # Красива таблиця
                print(tabulate(
                    formatted_rows,
                    headers=columns,
                    tablefmt="grid",
                    maxcolwidths=50
                ))
                print()

            except sqlite3.Error as e:
                print(f"ПОМИЛКА: {e}\n")
        
        print("Перевірку завершено успішно.")
        
    except Exception as e:
        print(f"КРИТИЧНА ПОМИЛКА: {e}")
    finally:
        if 'conn' in locals():
            conn.close()
            print("З'єднання закрито.")

# === Запуск ===
if __name__ == '__main__':
    check_database()