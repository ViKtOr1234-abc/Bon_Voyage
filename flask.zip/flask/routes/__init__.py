# routes/__init__.py
from flask import Flask

def init_routes(app: Flask):
    from .public import public_bp
    from .auth import auth_bp
    from .admin import admin_bp

    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)