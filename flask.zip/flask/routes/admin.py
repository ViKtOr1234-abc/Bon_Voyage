# routes/admin.py
from flask import Blueprint, request, session, jsonify
import os
from werkzeug.utils import secure_filename
from database import get_db
from functools import wraps

admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')

UPLOAD_FOLDERS = {
    'tour': 'static/images/tours',
    'promo': 'static/images/promotions'
}

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('is_admin'):
            return jsonify({"error": "Доступ заборонено"}), 403
        return f(*args, **kwargs)
    return decorated

def save_image_file(file, item_type):
    if not file or file.filename == '':
        return None
    
    # Завантажуємо папку
    upload_folder = UPLOAD_FOLDERS[item_type]
    if not os.path.exists(upload_folder):
        os.makedirs(upload_folder)
    
    # Використовуємо оригінальне ім'я файлу
    filename = secure_filename(file.filename)
    
    file_path = os.path.join(upload_folder, filename)
    file.save(file_path)
    
    return filename

# === ТУРИ ===
@admin_bp.route('/tours', methods=['GET', 'POST'])
@admin_required
def admin_tours():
    db = get_db()
    
    if request.method == 'GET':
        tours = db.execute('SELECT * FROM tours').fetchall()
        return jsonify([dict(t) for t in tours])
    
    elif request.method == 'POST':
        country = request.form.get('country')
        city = request.form.get('city')
        description = request.form.get('description')
        duration_days = request.form.get('duration_days')
        new_price_usd = request.form.get('new_price_usd')
        included = request.form.get('included')
        
        # Зберігаємо зображення
        image_filename = None
        if 'image' in request.files:
            image_file = request.files['image']
            if image_file and image_file.filename != '':  # Додано перевірку
                image_filename = save_image_file(image_file, 'tour')
        
        db.execute('''
            INSERT INTO tours 
            (country, city, description, duration_days, price_usd, included, image_filename)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            country,
            city,
            description,
            int(duration_days),
            int(new_price_usd),
            included,
            image_filename
        ))
        db.commit()
        return jsonify({"success": True})


@admin_bp.route('/tours/<int:tour_id>', methods=['GET', 'PUT', 'DELETE'])
@admin_required
def admin_tour_edit(tour_id):
    db = get_db()
    
    if request.method == 'GET':
        tour = db.execute('SELECT * FROM tours WHERE id = ?', (tour_id,)).fetchone()
        if not tour:
            return jsonify({"error": "Тур не знайдено"}), 404
        return jsonify(dict(tour))
    
    elif request.method == 'DELETE':
        db.execute('DELETE FROM tours WHERE id = ?', (tour_id,))
        db.commit()
        return jsonify({"success": True})
    
    elif request.method == 'PUT':
        country = request.form.get('country')
        city = request.form.get('city')
        description = request.form.get('description')
        duration_days = request.form.get('duration_days')
        new_price_usd = request.form.get('new_price_usd')
        included = request.form.get('included')
        
        # Отримуємо поточні дані
        current_tour = db.execute('SELECT image_filename FROM tours WHERE id = ?', (tour_id,)).fetchone()
        image_filename = current_tour['image_filename'] if current_tour else None
        
        # Якщо завантажено нове зображення
        if 'image' in request.files:
            image_file = request.files['image']
            if image_file and image_file.filename != '':  # Додано перевірку
                image_filename = save_image_file(image_file, 'tour')
        
        db.execute('''
            UPDATE tours SET 
            country=?, city=?, description=?, duration_days=?, 
            price_usd=?, included=?, image_filename=?
            WHERE id=?
        ''', (
            country,
            city,
            description,
            int(duration_days),
            int(new_price_usd),
            included,
            image_filename,
            tour_id
        ))
        db.commit()
        return jsonify({"success": True})


# === АКЦІЇ ===
@admin_bp.route('/promotions', methods=['GET', 'POST'])
@admin_required
def admin_promotions():
    db = get_db()
    
    if request.method == 'GET':
        promos = db.execute('SELECT * FROM promotions').fetchall()
        return jsonify([dict(p) for p in promos])
    
    elif request.method == 'POST':
        country = request.form.get('country')
        city = request.form.get('city')
        description = request.form.get('description')
        duration_days = request.form.get('duration_days')
        discount_percent = request.form.get('discount_percent')
        old_price_usd = request.form.get('old_price_usd')
        new_price_usd = request.form.get('new_price_usd')
        included = request.form.get('included')
        
        # Зберігаємо зображення
        image_filename = None
        if 'image' in request.files:
            image_file = request.files['image']
            if image_file and image_file.filename != '':  # Додано перевірку
                image_filename = save_image_file(image_file, 'promo')
        
        db.execute('''
            INSERT INTO promotions 
            (country, city, description, duration_days, discount_percent, old_price_usd, new_price_usd, included, image_filename)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            country,
            city,
            description,
            int(duration_days),
            int(discount_percent),
            int(old_price_usd),
            int(new_price_usd),
            included,
            image_filename
        ))
        db.commit()
        return jsonify({"success": True})


@admin_bp.route('/promotions/<int:promo_id>', methods=['GET', 'PUT', 'DELETE'])
@admin_required
def admin_promo_edit(promo_id):
    db = get_db()
    
    if request.method == 'GET':
        promo = db.execute('SELECT * FROM promotions WHERE id = ?', (promo_id,)).fetchone()
        if not promo:
            return jsonify({"error": "Акцію не знайдено"}), 404
        return jsonify(dict(promo))
    
    elif request.method == 'DELETE':
        db.execute('DELETE FROM promotions WHERE id = ?', (promo_id,))
        db.commit()
        return jsonify({"success": True})
    
    elif request.method == 'PUT':
        country = request.form.get('country')
        city = request.form.get('city')
        description = request.form.get('description')
        duration_days = request.form.get('duration_days')
        discount_percent = request.form.get('discount_percent')
        old_price_usd = request.form.get('old_price_usd')
        new_price_usd = request.form.get('new_price_usd')
        included = request.form.get('included')
        
        current_promo = db.execute('SELECT image_filename FROM promotions WHERE id = ?', (promo_id,)).fetchone()
        image_filename = current_promo['image_filename'] if current_promo else None
        
        if 'image' in request.files:
            image_file = request.files['image']
            if image_file and image_file.filename != '':  # Додано перевірку
                image_filename = save_image_file(image_file, 'promo')
        
        db.execute('''
            UPDATE promotions SET 
            country=?, city=?, description=?, duration_days=?, 
            discount_percent=?, old_price_usd=?, new_price_usd=?, included=?, image_filename=?
            WHERE id=?
        ''', (
            country,
            city,
            description,
            int(duration_days),
            int(discount_percent),
            int(old_price_usd),
            int(new_price_usd),
            included,
            image_filename,
            promo_id
        ))
        db.commit()
        return jsonify({"success": True})