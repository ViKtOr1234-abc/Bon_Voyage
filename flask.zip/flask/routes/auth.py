# routes/auth.py
from flask import Blueprint, request, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import sys
import os

# Додаємо кореневу папку в шлях
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from database import get_db

# Blueprint з префіксом /api
auth_bp = Blueprint('auth', __name__, url_prefix='/api')


@auth_bp.route('/login', methods=['POST'])
def api_login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({"success": False, "error": "Заповніть усі поля"}), 400
    
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
    
    if user and check_password_hash(user['password_hash'], password):
        session['user_id'] = user['id']
        session['is_admin'] = bool(user['is_admin'])
        return jsonify({"success": True, "is_admin": session['is_admin']})
    return jsonify({"success": False, "error": "Невірний логін або пароль"}), 401


@auth_bp.route('/register', methods=['POST'])
def api_register():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    name = data.get('name', '').strip()
    phone = data.get('phone', '').strip()
    email = data.get('email', '').strip()
    
    if not username or not password:
        return jsonify({"success": False, "error": "Заповніть логін і пароль"}), 400
    
    if len(password) < 6:
        return jsonify({"success": False, "error": "Пароль має бути ≥ 6 символів"}), 400
    
    db = get_db()
    existing = db.execute('SELECT id FROM users WHERE username = ?', (username,)).fetchone()
    if existing:
        return jsonify({"success": False, "error": "Користувач уже існує"}), 409
    
    hashed = generate_password_hash(password)
    db.execute('''
        INSERT INTO users (username, password_hash, name, phone, email)
        VALUES (?, ?, ?, ?, ?)
    ''', (username, hashed, name, phone, email))
    db.commit()
    return jsonify({"success": True, "message": "Реєстрація успішна"}), 201


@auth_bp.route('/logout', methods=['GET', 'POST'])
def api_logout():
    session.clear()
    return jsonify({"success": True})


@auth_bp.route('/check-auth')
def api_check_auth():
    return jsonify({
        "authenticated": 'user_id' in session,
        "is_admin": session.get('is_admin', False),
        "user_id": session.get('user_id')
    })


@auth_bp.route('/user/<int:user_id>')
def get_user_profile(user_id):
    if 'user_id' not in session or session['user_id'] != user_id:
        return jsonify({"error": "Доступ заборонено"}), 403
    
    db = get_db()
    user = db.execute('SELECT name, phone, email FROM users WHERE id = ?', (user_id,)).fetchone()
    if not user:
        return jsonify({"error": "Користувач не знайдений"}), 404
    
    return jsonify({
        "name": user['name'] or "",
        "phone": user['phone'] or "",
        "email": user['email'] or ""
    })


@auth_bp.route('/user/<int:user_id>', methods=['PUT'])
def update_user_profile(user_id):
    if 'user_id' not in session or session['user_id'] != user_id:
        return jsonify({"error": "Доступ заборонено"}), 403
    
    data = request.json
    name = data.get('name', '').strip()
    phone = data.get('phone', '').strip()
    email = data.get('email', '').strip()
    
    db = get_db()
    
    try:
        db.execute('''
            UPDATE users 
            SET name = ?, phone = ?, email = ?
            WHERE id = ?
        ''', (name, phone, email, user_id))
        db.commit()
        
        return jsonify({"success": True, "message": "Дані успішно оновлено"})
        
    except Exception as e:
        db.rollback()
        return jsonify({"error": "Помилка оновлення даних"}), 500

    
@auth_bp.route('/user/<int:user_id>/orders')
def get_user_orders(user_id):
    if 'user_id' not in session or session['user_id'] != user_id:
        return jsonify({"error": "Доступ заборонено"}), 403
    
    db = get_db()
    orders = db.execute('''
        SELECT o.*, 
               COALESCE(t.country, p.country) as country,
               COALESCE(t.city, p.city) as city,
               COALESCE(t.price_usd, p.new_price_usd) as price,
               o.status
        FROM orders o
        LEFT JOIN tours t ON o.item_type = 'tour' AND o.item_id = t.id
        LEFT JOIN promotions p ON o.item_type = 'promotion' AND o.item_id = p.id
        WHERE o.user_id = ?
        ORDER BY o.order_date DESC
    ''', (user_id,)).fetchall()
    
    return jsonify([dict(order) for order in orders])


@auth_bp.route('/user/<int:user_id>/favorites')
def get_user_favorites(user_id):
    """Отримати обране користувача"""
    if 'user_id' not in session or session['user_id'] != user_id:
        return jsonify({"error": "Доступ заборонено"}), 403
    
    db = get_db()
    favorites = db.execute('''
        SELECT 
            f.id,
            f.item_type,
            f.item_id,
            f.added_date,
            COALESCE(t.country, p.country) as country,
            COALESCE(t.city, p.city) as city,
            COALESCE(t.duration_days, p.duration_days) as duration_days,
            COALESCE(t.price_usd, p.new_price_usd) as price,
            COALESCE(t.included, p.included) as included,
            COALESCE(t.image_filename, p.image_filename) as image_filename
        FROM favorites f
        LEFT JOIN tours t ON f.item_type = 'tour' AND f.item_id = t.id
        LEFT JOIN promotions p ON f.item_type = 'promotion' AND f.item_id = p.id
        WHERE f.user_id = ?
        ORDER BY f.added_date DESC
    ''', (user_id,)).fetchall()
    
    # Фільтруємо записи де є дані (тур або акція існує)
    valid_favorites = [fav for fav in favorites if fav['country'] is not None]
    
    return jsonify([dict(fav) for fav in valid_favorites])


@auth_bp.route('/user/<int:user_id>/favorites', methods=['POST'])
def add_to_favorites(user_id):
    """Додати в обране"""
    if 'user_id' not in session or session['user_id'] != user_id:
        return jsonify({"error": "Доступ заборонено"}), 403
    
    data = request.json
    item_type = data.get('item_type')
    item_id = data.get('item_id')
    
    if not item_type or not item_id:
        return jsonify({"error": "Необхідно вказати тип та ID елемента"}), 400
    
    db = get_db()
    
    # Перевіряємо існування туру/акції
    if item_type == 'tour':
        item_exists = db.execute('SELECT id FROM tours WHERE id = ?', (item_id,)).fetchone()
    else:  # promotion
        item_exists = db.execute('SELECT id FROM promotions WHERE id = ?', (item_id,)).fetchone()
    
    if not item_exists:
        return jsonify({"error": "Тур або акція не знайдена"}), 404
    
    # Перевіряємо, чи не додано вже
    existing = db.execute(
        'SELECT id FROM favorites WHERE user_id = ? AND item_type = ? AND item_id = ?',
        (user_id, item_type, item_id)
    ).fetchone()
    
    if existing:
        return jsonify({"error": "Вже в обраному"}), 409
    
    db.execute(
        'INSERT INTO favorites (user_id, item_type, item_id) VALUES (?, ?, ?)',
        (user_id, item_type, item_id)
    )
    db.commit()
    
    return jsonify({"success": True, "message": "Додано в обране"})


@auth_bp.route('/user/<int:user_id>/favorites/<int:fav_id>', methods=['DELETE'])
def remove_from_favorites(user_id, fav_id):
    if 'user_id' not in session or session['user_id'] != user_id:
        return jsonify({"error": "Доступ заборонено"}), 403
    
    db = get_db()
    db.execute('DELETE FROM favorites WHERE id = ? AND user_id = ?', (fav_id, user_id))
    db.commit()
    
    return jsonify({"success": True, "message": "Видалено з обраного"})