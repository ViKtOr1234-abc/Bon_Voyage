# routes/public.py
from flask import Blueprint, send_from_directory, jsonify, request, session
from flask import current_app as app
from database import get_db

public_bp = Blueprint('public', __name__)

@public_bp.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

@public_bp.route('/<path:path>')
def serve_file(path):
    allowed_extensions = ('.html', '.css', '.js', '.jpg', '.jpeg', '.png', '.gif', '.ico', '.webp')
    allowed_prefixes = ('images/', 'admin/', 'css/', 'js/')
    
    if path.endswith(allowed_extensions) or any(path.startswith(p) for p in allowed_prefixes):
        return send_from_directory(app.static_folder, path)
    return "Not found", 404


# === ТУРИ ===
@public_bp.route('/api/tours')
def api_tours():
    db = get_db()
    tours = db.execute('''
        SELECT 
            id, 
            country, 
            city, 
            description, 
            duration_days,
            0 AS discount_percent,
            NULL AS old_price_usd,
            price_usd AS new_price_usd,
            included,
            image_filename
        FROM tours 
        ORDER BY price_usd
    ''').fetchall()
    return jsonify([dict(t) for t in tours])


# === АКЦІЇ ===
@public_bp.route('/api/promotions')
def api_promotions():
    db = get_db()
    promos = db.execute('''
        SELECT 
            id, 
            country, 
            city, 
            description, 
            duration_days,
            discount_percent,
            old_price_usd,
            new_price_usd,
            included,
            image_filename
        FROM promotions 
        ORDER BY discount_percent DESC
    ''').fetchall()
    return jsonify([dict(p) for p in promos])


# === РОУТ ЗБЕРЕЖЕННЯ ЗАМОВЛЕННЯ (ПРАЦЮЄ БЕЗ ВХОДУ) ===
@public_bp.route('/api/order', methods=['POST'])
def api_order():
    data = request.json
    required = ['item_type', 'item_id', 'name', 'phone', 'email']
    if not all(k in data for k in required):
        return jsonify({"error": "Заповніть усі поля"}), 400

    db = get_db()
    try:
        user_id = session.get('user_id')  # None → NULL

        db.execute('''
            INSERT INTO orders 
            (user_id, item_type, item_id, name, phone, email, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            user_id,
            data['item_type'],
            data['item_id'],
            data['name'],
            data['phone'],
            data['email'],
            data.get('notes', '')
        ))
        db.commit()
        return jsonify({"success": True, "message": "Замовлення успішно надіслано!"})
    
    except Exception as e:
        print("DB Error in /api/order:", str(e))
        return jsonify({"error": "Помилка сервера"}), 500