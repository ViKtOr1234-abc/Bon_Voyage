# reset_db.py
from werkzeug.security import generate_password_hash
import sqlite3
import os

def create_database():
    # Видаляємо стару БД
    if os.path.exists('data.db'):
        os.remove('data.db')
        print("Стара база даних видалена")

    conn = sqlite3.connect('data.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # === Створення таблиць ===
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tours (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            country TEXT NOT NULL,
            city TEXT NOT NULL,
            description TEXT,
            duration_days INTEGER,
            price_usd INTEGER NOT NULL,
            included TEXT,
            image_filename TEXT DEFAULT NULL
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS promotions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            country TEXT NOT NULL,
            city TEXT NOT NULL,
            description TEXT,
            duration_days INTEGER,
            discount_percent INTEGER,
            old_price_usd INTEGER,
            new_price_usd INTEGER,
            included TEXT,
            image_filename TEXT DEFAULT NULL
        )
    ''')
    
    # === Дані для турів ===
    tours_data = [
        ('Греція', 'Афіни', 'Афіни - історія, яка оживає. Акрополь та стародавні храми.', 6, 850, 'Авіапереліт, готель 3*, сніданки', 'athens.jpg'),
        ('Туреччина', 'Анталія', 'Анталія - сонце, море, гамаки. Відпочинок для душі.', 7, 720, 'Авіапереліт, готель 5*, all inclusive', 'antalya.jpg'),
        ('Португалія', 'Лісабон', 'Лісабон - теплий, акварельний. Місто семи пагорбів.', 5, 855, 'Авіапереліт, проживання 5 ночей', 'lisabon.jpg'),
        ('Хорватія', 'Дубровник', 'Дубровник - місто з серіалів. Стародавні стіни та море.', 6, 825, 'Авіапереліт, 6 ночей у готелі', 'dubrovnik.jpg'),
        ('Таїланд', 'Бангкок', 'Бангкок - хаос і краса. Храми та сучасні центри.', 9, 910, 'Переліт, проживання 9 ночей, готель 4*', 'bangkok.jpg')
    ]
    
    cursor.executemany('''
        INSERT INTO tours (country, city, description, duration_days, price_usd, included, image_filename)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', tours_data)
    
    # === Дані для акцій ===
    promotions_data = [
        ('Італія', 'Рим', 'Неймовірна подорож до серця історії - Рим. Колізей, Ватикан, стародавні руїни.', 6, 15, 1000, 850, 'Авіапереліт, проживання 6 ночей, 4-зірковий готель', 'rome.jpg'),
        ('Іспанія', 'Барселона', 'Барселона - місто кольорів та архітектури Гауді. Сантьяго Бернабеу.', 5, 20, 950, 760, 'Авіапереліт, проживання 5 ночей, екскурсії', 'barcelona.jpg'),
        ('Франція', 'Париж', 'Париж: мистецтво, любов, аромат круасанів. Ейфелева вежа, Лувр.', 7, 25, 1100, 825, 'Авіапереліт, готель 4*, трансфери', 'paris.jpg'),
        ('Японія', 'Токіо', 'Стародавні храми, сучасні мегаполіси - Токіо. Гора Фудзі, сакура.', 7, 30, 1800, 1260, 'Переліт, проживання 7 ночей, 5-зірковий готель', 'tokyo.jpg'),
        ('Єгипет', 'Хургада', 'Сонце, піраміди, Червоне море - незабутні враження. Дайвінг, екскурсії.', 7, 15, 1000, 850, 'Переліт, all inclusive 7 днів, аквапарк', 'hurghada.jpg')
    ]
    
    cursor.executemany('''
        INSERT INTO promotions (country, city, description, duration_days, discount_percent, old_price_usd, new_price_usd, included, image_filename)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', promotions_data)
    
    # === Інші таблиці без змін ===
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_admin BOOLEAN DEFAULT 0,
            name TEXT,
            phone TEXT,
            email TEXT
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            item_type TEXT NOT NULL,
            item_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT NOT NULL,
            notes TEXT,
            order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'нове',
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS favorites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            item_type TEXT NOT NULL,
            item_id INTEGER NOT NULL,
            added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    conn.commit()

    # === Додавання адміна ===
    cursor.execute('''
        INSERT OR IGNORE INTO users (username, password_hash, is_admin)
        VALUES (?, ?, ?)
    ''', ('admin', generate_password_hash('admin123'), 1))
    
    conn.commit()
    
    # === Перевірка ===
    cursor.execute("SELECT COUNT(*) FROM tours")
    tours_count = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM promotions")
    promotions_count = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM users")
    users_count = cursor.fetchone()[0]
    
    conn.close()
    
    print("НОВА БАЗА ДАНИХ СТВОРЕНА З НУЛЯ!")
    print(f"Турів: {tours_count}")
    print(f"Акцій: {promotions_count}")
    print(f"Користувачів: {users_count}")
    print("Адмін: login=admin, password=admin123")

# === ЗАПУСК ===
if __name__ == '__main__':
    create_database()